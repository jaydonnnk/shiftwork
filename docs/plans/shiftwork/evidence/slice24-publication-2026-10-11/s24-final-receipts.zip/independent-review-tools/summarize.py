import json, re, sys
text = open("C:/swrev24-tools/out/mutate.log", encoding="utf-8").read()
blocks = [json.loads(b) for b in re.findall(r"(?ms)^\{\n.*?^\}", text)]
base = {name for name, _ in blocks[0]["failed"]}
print("baseline ran", blocks[0]["ran"], "baseline failures (probe findings):", len(base))
for b in blocks[1:]:
    new = [(n, m.split("\n")[0][:110]) for n, m in b["failed"] if n not in base]
    gone = sorted(base - {n for n, _ in b["failed"]})
    shipped = [n for n, _ in new if not n.startswith("test_probe")]
    print(f"\n== {b['fault']}: ran {b['ran']}, newly failing {len(new)} (shipped tests {len(shipped)})")
    for n, m in new: print("   +", n, "|", m)
    for n in gone: print("   - no longer failing:", n)
