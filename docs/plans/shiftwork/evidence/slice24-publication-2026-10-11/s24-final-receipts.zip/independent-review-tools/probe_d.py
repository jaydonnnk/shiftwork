

# --- Probe D: unassessed GTM capture labelled as rejected by an assessment ---

def test_probe_unassessed_capture_label(tmp_path, monkeypatch):
    path = tmp_path / "unassessed.db"
    with TestClient(create_app(str(path), executor="local_process"), raise_server_exceptions=False) as client:
        flow = gtm.qualify_gtm(client)
        shift = gtm.gtm_next_shift(client, flow["shift_id"])
        def bug(*args, **kwargs): raise RuntimeError("probe reducer failure")
        monkeypatch.setattr(orchestrator.reducer, "reduce_operation", bug)
        started = client.post(f"/api/shifts/{shift['id']}/runs", json={"client_request_id": "rv-unassessed"})
        run_id = started.json()["id"] if started.status_code == 202 else None
        conn = db.connect(path)
        try:
            run_id = run_id or conn.execute("SELECT id FROM runs WHERE client_request_id='rv-unassessed'").fetchone()[0]
            run = repo.get_run(conn, run_id)
            n_assess = len(repo.list_task_assessment_models(conn, run_id))
            n_out = len(repo.list_outputs(conn, run_id))
        finally:
            conn.close()
        outputs = client.get(f"/api/runs/{run_id}/outputs")
        text = outputs.json()[0]["customer_answer"]["display_text"] if outputs.status_code == 200 else outputs.text
        print("PROBE-D", run.state.value, run.failure_kind, "assessments", n_assess, "outputs", n_out, "|", text)
        assert not (n_assess == 0 and "rejected by the independent assessment" in text), text
