#!/bin/sh
export PYTHONPATH="C:/Users/jayd0/OneDrive/Desktop/nebius_nvidia/.venv313/Lib/site-packages"
export PYTHONNOUSERSITE=1
export PYTHONDONTWRITEBYTECODE=1
cd /c/swrev24 && exec "/c/Users/jayd0/AppData/Roaming/uv/python/cpython-3.13.14-windows-x86_64-none/python.exe" -B "$@"
