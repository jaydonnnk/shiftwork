"""Reviewer fault runner for the disposable copy C:/swrev24 only."""
import hashlib, json, re, subprocess, sys, xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path("C:/swrev24")
OUT = Path("C:/swrev24-tools/out"); OUT.mkdir(exist_ok=True)
assert "OneDrive" not in str(ROOT)

def scoped(raw, scope, old, new):
    starts = list(re.finditer(rb"(?m)^def " + scope.encode() + rb"\(", raw))
    assert len(starts) == 1, scope
    s = starts[0].start(); nxt = re.search(rb"(?m)^def ", raw[starts[0].end():])
    e = starts[0].end() + nxt.start() if nxt else len(raw)
    body = raw[s:e]
    o, n = old.encode(), new.encode()
    if body.count(o) != 1:
        o, n = o.replace(b"\n", b"\r\n"), n.replace(b"\n", b"\r\n")
    assert body.count(o) == 1, f"anchor count {body.count(o)} in {scope}"
    return raw[:s] + body.replace(o, n, 1) + raw[e:]

def run(name, file, scope, old, new, targets):
    path = ROOT / file; raw = path.read_bytes(); digest = hashlib.sha256(raw).hexdigest()
    xml = OUT / f"{name}.xml"
    try:
        path.write_bytes(scoped(raw, scope, old, new))
        subprocess.run([sys.executable, "-B", "-m", "pytest", *targets, "-q", "-p", "no:cacheprovider",
                        f"--junitxml={xml}"], cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=1200)
    finally:
        path.write_bytes(raw)
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    cases = list(ET.parse(xml).getroot().iter("testcase"))
    failed = [(c.get("name"), (c.find("failure") if c.find("failure") is not None else c.find("error")).get("message", "")[:140])
              for c in cases if c.find("failure") is not None or c.find("error") is not None]
    print(json.dumps({"fault": name, "ran": len(cases), "failed": failed}, indent=1), flush=True)

OR = "shiftwork/orchestrator.py"
REP = "tests/orchestrator/test_gtm_review_repairs.py"
PRB = "tests/orchestrator/test_zz_review_probes.py"
FAULTS = {
 # the three newest named S24 faults, re-applied independently
 "missing_task_assurance": (OR, "output_evidence_for", "rejected = (any(not row.mandatory_pass for row in assessed)", "rejected = (False"),
 "unreadable_replay_binding": (OR, "replay_assessment", "except (ValueError, TypeError):", "except ():"),
 "unreadable_history_binding": (OR, "_pipeline_history_context", "except (ValueError, TypeError) as exc:", "except () as exc:"),
 # reviewer-derived narrower faults
 "replay_drop_typeerror": (OR, "replay_assessment", "except (ValueError, TypeError):", "except ValueError:"),
 "history_drop_typeerror": (OR, "_pipeline_history_context", "except (ValueError, TypeError) as exc:", "except ValueError as exc:"),
 "replay_outputs_outside_try": (OR, "replay_assessment",
    "        outputs = repo.list_outputs(conn, run.id)\n    except (ValueError, TypeError):",
    "        pass\n    except (ValueError, TypeError):\n        return _unknown_inputs_report(run.id)\n    outputs = repo.list_outputs(conn, run.id)\n    if False:"),
 "history_loop2_unconverted": (OR, "_verify_pipeline_history",
    "context = _pipeline_history_context(conn, run.context_id) if run.context_id else None",
    "context = repo.get_execution_context(conn, run.context_id) if run.context_id else None"),
}

def _main():
    for name in sys.argv[1:]:
        file, scope, old, new = FAULTS[name]
        run(name, file, scope, old, new, [REP, PRB])
FAULTS["baseline"] = (OR, "replay_assessment", "except (ValueError, TypeError):", "except (ValueError, TypeError):")

_main()
