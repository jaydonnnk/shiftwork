"""Independent review probes for S24 R1/R2 (disposable copy only, never the workspace).

Each probe asserts the behavior the R1/R2 claims imply. A failure is a finding.
"""
import base64
import json

import pytest
from fastapi.testclient import TestClient

from shiftwork import experiments, orchestrator
from shiftwork.app import create_app
from shiftwork.domain.models import ExecutorFailure, RunState
from shiftwork.executor.local_process import LocalProcessAdapter
from shiftwork.store import db, repo
from tests.orchestrator import test_gtm_pipeline as gtm
from tests.orchestrator.test_gtm_review_repairs import history, operated_history, rows  # noqa: F401

DAMAGES = ["spec_binding_absent", "condition_binding_absent", "workload_count_type", "mission_bytes_text"]


def corrupt(conn, context_id, damage):
    context = repo.get_execution_context(conn, context_id)
    if damage == "condition_binding_absent":
        value = context.condition.model_dump(mode="json"); del value["content_hash"]
        conn.execute("UPDATE execution_contexts SET condition_json=? WHERE id=?", (json.dumps(value), context_id))
    elif damage == "mission_bytes_text":
        # BLOB affinity accepts TEXT; the loader then calls b64encode(str) -> TypeError.
        conn.execute("UPDATE execution_contexts SET mission_bytes=? WHERE id=?", ("not-bytes", context_id))
    else:
        value = [item.model_dump(mode="json") for item in context.workloads]
        if damage == "spec_binding_absent": del value[0]["request_specs_hash"]
        else: value[0]["request_count"] = "corrupted-count"
        conn.execute("UPDATE execution_contexts SET workloads_json=? WHERE id=?", (json.dumps(value), context_id))
    conn.commit()


def outcome(fn):
    try:
        return ("returned", fn())
    except orchestrator.LifecycleError as exc:
        return ("LifecycleError", f"{exc.kind}: {exc}")
    except Exception as exc:  # noqa: BLE001 - the probe records the leak class
        return ("LEAK", f"{type(exc).__module__}.{type(exc).__name__}: {str(exc)[:160]}")


# --- Probe A: retained context re-read by content hash (freeze reuse) -------

@pytest.mark.parametrize("damage", DAMAGES)
def test_probe_operation_freeze_reuses_unreadable_context(history, damage):
    conn, run, shift = history
    ctx = orchestrator.freeze_diagnostic_context(conn, shift, operation=True)
    conn.commit()  # retained, as a failed first attempt's reservation would be
    corrupt(conn, ctx.id, damage)
    before = rows(conn)
    got = outcome(lambda: orchestrator.freeze_diagnostic_context(conn, shift, operation=True))
    print("PROBE-A", damage, got)
    assert rows(conn) == before
    assert got[0] == "LifecycleError", got


@pytest.mark.parametrize("damage", DAMAGES)
def test_probe_diagnostic_freeze_reuses_unreadable_context(history, damage):
    conn, run, shift = history
    ctx = orchestrator.freeze_diagnostic_context(conn, shift)
    conn.commit()
    corrupt(conn, ctx.id, damage)
    got = outcome(lambda: orchestrator.freeze_diagnostic_context(conn, shift))
    print("PROBE-A2", damage, got)
    assert got[0] == "LifecycleError", got


def test_probe_api_retry_after_failed_attempt(tmp_path):
    path = tmp_path / "retry.db"
    with TestClient(create_app(str(path), executor="local_process"), raise_server_exceptions=False) as client:
        flow = gtm.qualify_gtm(client)
        shift = gtm.gtm_next_shift(client, flow["shift_id"])
        conn = db.connect(path)
        try:
            first = orchestrator.start_run(conn, shift["id"], executor="local_process", client_request_id="rv-first")
            # The provision-failure branch of execute_selected_operation leaves exactly this state.
            repo.update_run(conn, first.id, RunState.FAILED, ExecutorFailure.PROVISION_FAILED, orchestrator._now())
            conn.commit()
            healthy_ctx = first.context_id
            corrupt(conn, healthy_ctx, "spec_binding_absent")
        finally:
            conn.close()
        retry = client.post(f"/api/shifts/{shift['id']}/runs", json={"client_request_id": "rv-retry"})
        print("PROBE-A3 retry", retry.status_code, retry.text[:200])
        assert retry.status_code == 409, retry.text


# --- Probe B: other retained rows read by replay / inheritance / projection --

def test_probe_replay_unreadable_ledger_event(history):
    conn, run, shift = history
    seq = conn.execute("SELECT MIN(seq) FROM ledger_events WHERE engagement_slug='gtm'").fetchone()[0]
    conn.execute("UPDATE ledger_events SET event_type='NOT_A_TYPE' WHERE engagement_slug='gtm' AND seq=?", (seq,))
    conn.commit()
    replay = outcome(lambda: orchestrator.replay_assessment(conn, run.id))
    inherit = outcome(lambda: orchestrator.freeze_diagnostic_context(conn, shift, operation=True))
    print("PROBE-B1 replay", replay); print("PROBE-B1 inherit", inherit)
    assert replay[0] != "LEAK" and inherit[0] != "LEAK", (replay, inherit)


@pytest.mark.parametrize("column,value", [("reason_code", "NOT_A_CODE"), ("verdict", "maybe")])
def test_probe_replay_unreadable_check_result(history, column, value):
    conn, run, shift = history
    cid = conn.execute("SELECT id FROM check_results WHERE run_id=? ORDER BY rowid LIMIT 1", (run.id,)).fetchone()[0]
    conn.execute(f"UPDATE check_results SET {column}=? WHERE id=?", (value, cid))
    conn.commit()
    replay = outcome(lambda: orchestrator.replay_assessment(conn, run.id))
    inherit = outcome(lambda: orchestrator.freeze_diagnostic_context(conn, shift, operation=True))
    print("PROBE-B2", column, "replay", replay, "inherit", inherit)
    assert replay[0] != "LEAK" and inherit[0] != "LEAK", (replay, inherit)


def test_probe_projection_unreadable_task_assessment(history):
    conn, run, shift = history
    conn.execute("UPDATE task_assessments SET reason_codes_json=? WHERE run_id=? AND task_id='owner'",
                 ('["NOT_A_CODE"]', run.id))
    conn.commit()
    output = repo.list_outputs(conn, run.id)[0]
    got = outcome(lambda: orchestrator.output_evidence_for(conn, output, run))
    print("PROBE-B3", got if got[0] != "returned" else got[1]["customer_answer"])
    assert got[0] != "LEAK", got


def test_probe_replay_unreadable_output_is_converted(history):
    conn, run, shift = history
    conn.execute("UPDATE run_outputs SET transport_error='NOT_A_FAILURE' WHERE run_id=?", (run.id,))
    conn.commit()
    replay = outcome(lambda: orchestrator.replay_assessment(conn, run.id))
    inherit = outcome(lambda: orchestrator.freeze_diagnostic_context(conn, shift, operation=True))
    print("PROBE-B4 replay", replay, "inherit", inherit)
    assert replay[0] == "returned" and replay[1].status == "UNKNOWN_MISSING_INPUTS", replay
    assert inherit[0] == "LifecycleError", inherit


@pytest.mark.parametrize("damage", ["mission_bytes_text"])
def test_probe_typeerror_arm(history, damage):
    conn, run, shift = history
    corrupt(conn, run.context_id, damage)
    replay = outcome(lambda: orchestrator.replay_assessment(conn, run.id))
    inherit = outcome(lambda: orchestrator.freeze_diagnostic_context(conn, shift, operation=True))
    print("PROBE-B5 replay", replay, "inherit", inherit)
    assert replay[0] == "returned" and replay[1].status == "UNKNOWN_MISSING_INPUTS", replay
    assert inherit[0] == "LifecycleError" and "unreadable" in inherit[1], inherit


# --- Probe C: R1-style assurance on the diagnostic surface -------------------

@pytest.mark.parametrize("missing", [(), ("owner", "write")], ids=["starter_as_is", "both_missing"])
def test_probe_diagnostic_text_missing_required_tasks(tmp_path, monkeypatch, missing):
    path = tmp_path / "diag.db"
    with TestClient(create_app(str(path), executor="local_process")) as client:
        flow = gtm.prepare_flow(client, None)
        original = LocalProcessAdapter.execute
        async def omit(self, request):
            result = await original(self, request)
            raw = json.loads(result.captures[0].body)
            raw["task_results"] = [row for row in raw["task_results"] if row["task_id"] not in missing]
            return result.model_copy(update={"captures": (result.captures[0].model_copy(update={"body": json.dumps(raw).encode()}),)})
        monkeypatch.setattr(LocalProcessAdapter, "execute", omit)
        conn = db.connect(path)
        try:
            exp = experiments.create_diagnostic_experiment(conn, flow["shift_id"], candidate_version_id=flow["starter"]["selected_version_id"],
                investigation_id=flow["investigation_id"], client_request_id="rv-diag")
            run = experiments.experiment_run(conn, exp.id)
            experiments.execute_experiment(conn, run.id)
            view = client.get(f"/api/experiments/{exp.id}").json()
        finally:
            conn.close()
        trial = view["trials"][0]; print("PROBE-C trial keys", sorted(trial), trial.get("state"))
        failing = [a for a in trial["task_assessments"] if not a["mandatory_pass"]]
        text = json.dumps(view)
        print("PROBE-C failing", [(a["task_id"], a["reason_codes"]) for a in failing])
        print("PROBE-C customer_text", repr(trial.get("customer_text")))
        print("PROBE-C keys", sorted(view))
        assert failing, "probe vacuous: no failing assessment"
        assert "No additional owner, record or handoff is required." not in (trial.get("customer_text") or "")
        assert "rejected" in (trial.get("customer_text") or "rejected")


# --- Probe D: unassessed GTM capture labelled as rejected by an assessment ---

def test_probe_unassessed_capture_label(tmp_path, monkeypatch):
    path = tmp_path / "unassessed.db"
    with TestClient(create_app(str(path), executor="local_process"), raise_server_exceptions=False) as client:
        flow = gtm.qualify_gtm(client)
        shift = gtm.gtm_next_shift(client, flow["shift_id"])
        def bug(*args, **kwargs): raise RuntimeError("probe reducer failure")
        monkeypatch.setattr(orchestrator, "finalize_selected_operation", lambda conn, run_id: repo.get_run(conn, run_id))
        started = client.post(f"/api/shifts/{shift['id']}/runs", json={"client_request_id": "rv-unassessed"})
        print("PROBE-D start", started.status_code, started.text[:200]); run_id = started.json()["id"] if started.status_code == 202 else None
        conn = db.connect(path)
        try:
            run_id = run_id or conn.execute("SELECT id FROM runs WHERE client_request_id='rv-unassessed'").fetchone()[0]
            run = repo.get_run(conn, run_id)
            n_assess = len(repo.list_task_assessment_models(conn, run_id))
            n_out = len(repo.list_outputs(conn, run_id))
        finally:
            conn.close()
        outputs = client.get(f"/api/runs/{run_id}/outputs")
        text = outputs.json()[0]["customer_answer"]["display_text"] if outputs.status_code == 200 else outputs.text
        print("PROBE-D", run.state.value, run.failure_kind, "assessments", n_assess, "outputs", n_out, "|", text)
        assert not (n_assess == 0 and "rejected by the independent assessment" in text), text
