import hashlib
import json
from pathlib import Path
import runpy
import sqlite3
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(r'C:\Users\jayd0\OneDrive\Desktop\nebius_nvidia')
OUT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'docs/plans/shiftwork/evidence/slice23-application-2026-10-07'
sys.path.insert(0, str(ROOT))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def read(path):
    return json.loads(path.read_bytes())

def exclusive(path, data):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')

def snapshot():
    paths = {p for p in git('ls-files', '-z').decode().split('\0') if p}
    paths.update(row['path'] for row in read(ROOT / 'docs/plans/shiftwork/slice23-publication-inventory-2026-10-07.json')['files'])
    paths.update(p.relative_to(ROOT).as_posix() for p in (ROOT / 'docs/plans/shiftwork/evidence').rglob('*') if p.is_file())
    data = dict(head=git('rev-parse', 'HEAD').decode().strip(),
                branch=git('branch', '--show-current').decode().strip(),
                index_sha256=hashlib.sha256(git('ls-files', '--stage', '-z')).hexdigest(),
                files={p: sha(ROOT / p) for p in sorted(paths)})
    exclusive(OUT / 'review-entry.json', data)
    print(json.dumps(dict(files=len(data['files']), head=data['head'], branch=data['branch'])))

def audit():
    from demos.gtm_reviewed import reviewed_inventory
    inventory = reviewed_inventory()
    application = read(EVIDENCE / 'application.json')
    entry = read(EVIDENCE / 'entry.json')
    older = read(ROOT / 'docs/plans/shiftwork/evidence/slice23-preflight-2026-10-07/entry.json')
    for row in application['production_replacements']:
        assert sha(ROOT / row['path']) == row['proposed_sha256']
        assert (ROOT / row['path']).stat().st_size == row['proposed_bytes']
        assert sha(EVIDENCE / 'preimages' / row['path']) == row['preimage_sha256']
    for p in entry['historical_evidence_paths']:
        assert sha(ROOT / p) == entry['files'][p], p
    for p, digest in older['prior_evidence'].items():
        assert sha(ROOT / p) == digest, p
    for p, digest in entry['prior_reviewed_pins'].items():
        assert sha(ROOT / 'shiftwork' / p) == digest, p
    bindings = read(EVIDENCE / 'proof-source-bindings.json')
    for p, digest in bindings.items():
        assert sha(ROOT / p) == digest, p
    faults = read(EVIDENCE / 'mutations-reviewed/results.json')
    assert len(faults) == len({f['name'] for f in faults}) == 106
    for f in faults:
        stem = EVIDENCE / 'mutations-reviewed' / f['name']
        assert sha(stem.with_suffix('.log')) == f['log_sha256']
        assert sha(stem.with_suffix('.xml')) == f['xml_sha256']
        cases = list(ET.parse(stem.with_suffix('.xml')).getroot().iter('testcase'))
        assert len(cases) == 1
        failures = cases[0].findall('failure')
        assert len(failures) == 1 and not cases[0].findall('error')
        assert failures[0].get('message') == f['message'], f['name']
        assert f['errors'] == 0 and f['failures'] == 1 and f['restored']
        assert f['message'].startswith(('assert', 'AssertionError', 'Failed: DID NOT RAISE')), f['name']
    publication_path = ROOT / 'docs/plans/shiftwork/slice23-publication-inventory-2026-10-07.json'
    publication = read(publication_path)
    rows = publication['files']
    paths = {r['path'] for r in rows}
    assert len(paths) == len(rows)
    assert {'.gitignore', 'AGENTS.md'}.isdisjoint(paths)
    assert {'shiftwork/' + r['path'] for r in inventory['files']} <= paths
    assert len(publication['hidden_required_requests']) == 8
    for r in rows:
        assert sha(ROOT / r['path']) == r['sha256'], r['path']
        assert (ROOT / r['path']).stat().st_size == r['bytes']
    final = read(EVIDENCE / 'final-preservation.json')
    assert sha(publication_path) == final['publication_manifest_sha256']
    data = dict(status='PASS', production_replacements=4, material_pins=19, seals=2,
                document_bindings=3, fixture_pins=3, incoming_evidence=len(entry['historical_evidence_paths']),
                pre_s23_evidence=len(older['prior_evidence']), prior_reviewed=len(entry['prior_reviewed_pins']),
                source_bindings=len(bindings), retained_faults_with_matching_assertions=len(faults),
                publication_files=len(rows), hidden_requests=8)
    exclusive(OUT / 'independent-bindings-audit.json', data)
    print(json.dumps(data))

def database():
    proof = read(EVIDENCE / 'production-retained.json')
    path = EVIDENCE / 'production-retained.db'
    digest = sha(path)
    assert digest == proof['database_sha256']
    conn = sqlite3.connect(path.as_uri() + '?mode=ro&immutable=1', uri=True)
    conn.row_factory = sqlite3.Row
    assert conn.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
    experiment = conn.execute('SELECT * FROM experiments WHERE id=?', (proof['comparison']['id'],)).fetchone()
    slots = conn.execute('SELECT * FROM trial_slots WHERE experiment_id=? ORDER BY execution_ordinal', (experiment['id'],)).fetchall()
    assert [(s['pair_ordinal'], s['candidate_label']) for s in slots] == [(1,'A'),(1,'B'),(2,'B'),(2,'A'),(3,'A'),(3,'B')]
    for pair in (1,2,3):
        a,b = [s for s in slots if s['pair_ordinal'] == pair]
        assert a['request_batch_hash'] == b['request_batch_hash']
        assert a['protected_variant_refs_json'] == b['protected_variant_refs_json']
    for table, expected in proof['business_rows_before'].items():
        assert expected == proof['business_rows_after'][table]
        assert [list(r) for r in conn.execute('SELECT * FROM ' + table + ' ORDER BY rowid')] == expected
    assert conn.execute('SELECT COUNT(*) FROM run_outputs').fetchone()[0] == 25
    assert all(s['state'] == 'COMPLETE' and s['request_count'] == 3 and s['executed_request_count'] == 4 for s in slots)
    events = conn.execute('SELECT * FROM assist_events ORDER BY created_at').fetchall()
    assert [e['role'] for e in events] == ['HINT','DIAGNOSIS']
    assert all(e['reported_model_id'] is None and e['proposed_patch'] is None for e in events)
    assert all(e['eligible'] for e in proof['comparison']['outcome']['eligibility'])
    conn.close()
    assert sha(path) == digest
    exclusive(OUT / 'independent-database-audit.json', dict(status='PASS', digest=digest, captures=25, paired_slots=6, source='read-only immutable SQLite'))
    print('PASS: read-only database, six paired slots, 25 captures, unchanged business rows, fake assist evidence')

def preserve():
    entry = read(OUT / 'review-entry.json')
    drift = [p for p,h in entry['files'].items() if not (ROOT / p).is_file() or sha(ROOT / p) != h]
    assert not drift, drift
    assert git('rev-parse', 'HEAD').decode().strip() == entry['head']
    assert git('branch', '--show-current').decode().strip() == entry['branch']
    assert hashlib.sha256(git('ls-files', '--stage', '-z')).hexdigest() == entry['index_sha256']
    exclusive(OUT / 'review-preservation.json', dict(status='PASS', files_unchanged=len(entry['files']), index_head_branch_unchanged=True))
    print('PASS: ' + str(len(entry['files'])) + ' entry files and index/HEAD/branch unchanged')

def publication():
    manifest = read(ROOT / 'docs/plans/shiftwork/slice23-publication-inventory-2026-10-07.json')
    rows = manifest['files']
    paths = {r['path'] for r in rows}
    changed = {p for p in git('diff', '--name-only', 'HEAD', '-z').decode().split('\0') if p}
    assert changed - {'.gitignore', 'AGENTS.md'} <= paths
    visible = {p for p in git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0') if p}
    assert visible <= paths | {manifest['also_include_manifest'], manifest['also_include_final_preservation_receipt']}
    ignored = subprocess.run(['git', 'check-ignore', '--stdin', '-z', '--no-index'], cwd=ROOT,
                             input=('\0'.join(sorted(paths)) + '\0').encode(), capture_output=True)
    assert ignored.returncode in (0,1)
    ignored_paths = {p for p in ignored.stdout.decode().split('\0') if p}
    for row in rows:
        assert row['explicit_force_inclusion_required'] == (row['path'] in ignored_paths), row['path']
    protected = [r['path'] for r in rows if r['group'] in ('approved-material','verification-receipts')
                 or r['path'] in ('shiftwork/config.py','shiftwork/packs/registry.py')
                 or r['path'].endswith(('slice23-gtm-review-inventory.json','slice23-gtm-operator-review-packet.md'))]
    attr = subprocess.check_output(['git','check-attr','--stdin','-z','text'], cwd=ROOT,
                                  input=('\0'.join(protected)+'\0').encode()).decode().split('\0')
    assert len(attr) == len(protected)*3 + 1
    assert all(attr[i+2] == 'unset' for i in range(0,len(attr)-1,3))
    raw = subprocess.check_output(['git','hash-object','--no-filters','--stdin-paths'], cwd=ROOT,
                                  input=('\n'.join(protected)+'\n').encode())
    clean = subprocess.check_output(['git','hash-object','--stdin-paths'], cwd=ROOT,
                                    input=('\n'.join(protected)+'\n').encode())
    assert raw == clean
    assert all((ROOT / p).is_file() for p in (manifest['also_include_manifest'], manifest['also_include_final_preservation_receipt']))
    data = dict(status='PASS', inventory_rows=len(rows), additional_manifest_and_preservation_files=2,
                ignored_paths=len(ignored_paths), explicit_hidden_requests=len(manifest['hidden_required_requests']),
                byte_preserving_filters=len(protected), visible_dirty_scope_complete=True,
                excluded_unowned_paths=['.gitignore','AGENTS.md'], fresh_git_checkout='NOT_RUN')
    exclusive(OUT / 'independent-publication-audit.json', data)
    print(json.dumps(data))

def faults():
    retained = {f['name']: f for f in read(EVIDENCE / 'mutations-reviewed/results.json')}
    fresh = read(OUT / 'faults-rerun/results.json')
    assert len(fresh) == len(retained) == len({f['name'] for f in fresh}) == 106
    files = read(OUT / 'isolated-entry.json')
    for f in fresh:
        old = retained[f['name']]
        assert f['status'] == 'FAIL_CAUGHT' and f['failures'] == 1 and f['errors'] == 0 and f['restored']
        assert f['node'] == old['node'] and f['source_sha256'] == old['source_sha256']
        assert f['message'].splitlines()[0] == old['message'].splitlines()[0], f['name']
        stem = OUT / 'faults-rerun' / f['name']
        assert sha(stem.with_suffix('.xml')) == f['xml_sha256']
        assert sha(stem.with_suffix('.log')) == f['log_sha256']
        cases = list(ET.parse(stem.with_suffix('.xml')).getroot().iter('testcase'))
        assert len(cases) == 1 and len(cases[0].findall('failure')) == 1 and not cases[0].findall('error')
        assert cases[0].find('failure').get('message') == f['message']
    for p,digest in files.items():
        assert sha(OUT / 'isolated-s23' / p) == digest, p
    data = dict(status='PASS', controls=106, intended_assertions_match=106, setup_errors=0,
                isolated_source_files_restored_exactly=len(files), product_checkout_faulted=False,
                command=[str(ROOT / '.venv313/Scripts/python.exe'), '-B', 'tests/packs/gtm_mutation_proofs.py', '--out', str(OUT / 'faults-rerun')],
                cwd=str(OUT / 'isolated-s23'))
    exclusive(OUT / 'independent-fault-audit.json', data)
    print(json.dumps(data))

if __name__ == '__main__':
    globals()[sys.argv[1]]()
