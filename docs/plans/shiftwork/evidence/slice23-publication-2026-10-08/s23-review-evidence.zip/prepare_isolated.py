import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(r'C:\Users\jayd0\OneDrive\Desktop\nebius_nvidia')
OUT = Path(__file__).resolve().parent
ISOLATED = OUT / 'isolated-s23'
assert not ISOLATED.exists()
ISOLATED.mkdir()
for directory in ('shiftwork', 'tests', 'demos'):
    shutil.copytree(ROOT / directory, ISOLATED / directory,
                    ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache', '*.pyc'))
for relative in ('pyproject.toml', 'docs/plans/shiftwork/slice23-gtm-review-inventory.json',
                 'docs/plans/shiftwork/slice23-gtm-operator-review-packet.md',
                 'docs/plans/shiftwork/evidence/slice23-approval-handoff-2026-10-07/authorization.json'):
    dest = ISOLATED / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / relative, dest)
files = {p.relative_to(ISOLATED).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in ISOLATED.rglob('*') if p.is_file()}
for relative, digest in files.items():
    assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == digest
(OUT / 'isolated-entry.json').write_text(json.dumps(files, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(isolated_root=str(ISOLATED), exact_copied_files=len(files))))
