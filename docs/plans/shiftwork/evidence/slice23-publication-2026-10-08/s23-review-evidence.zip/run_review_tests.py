import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(r'C:\Users\jayd0\OneDrive\Desktop\nebius_nvidia')
OUT = Path(__file__).resolve().parent
name, *selection = sys.argv[1:]
assert name.replace('-', '').isalnum()
log = OUT / (name + '.log')
xml = OUT / (name + '.xml')
result = OUT / (name + '-result.json')
assert not any(p.exists() for p in (log, xml, result))
command = [sys.executable, '-B', '-m', 'pytest', *selection, '-q', '--tb=short',
           '-p', 'no:cacheprovider', '--junitxml=' + str(xml)]
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
env.pop('SHIFTWORK_S23_PROOF_OUT', None)
with log.open('xb') as stream:
    proc = subprocess.Popen(command, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for line in iter(proc.stdout.readline, b''):
        stream.write(line)
        stream.flush()
        print(line.decode(errors='replace').rstrip(), flush=True)
    code = proc.wait()
suites = list(ET.parse(xml).getroot().iter('testsuite'))
summary = {k: sum(int(s.get(k, 0)) for s in suites) for k in ('tests', 'failures', 'errors', 'skipped')}
receipt = dict(command=command, exit_code=code, **summary,
               log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
               xml_sha256=hashlib.sha256(xml.read_bytes()).hexdigest())
result.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt))
sys.exit(code)
