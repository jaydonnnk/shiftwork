import base64
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import sys

ROOT = Path(r'C:\Users\jayd0\OneDrive\Desktop\nebius_nvidia')
OUT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'docs/plans/shiftwork/evidence/slice23-application-2026-10-07'
sys.path.insert(0, str(ROOT))
from shiftwork import comparison_flow
from shiftwork.store import db, repo

proof = json.loads((EVIDENCE / 'production-retained.json').read_bytes())
database = OUT / 'readback-probes-v2.db'
assert not database.exists()
shutil.copyfile(EVIDENCE / 'production-retained.db', database)
conn = db.connect(database)
experiment_id = proof['comparison']['id']
experiment = repo.get_experiment(conn, experiment_id)
context_id = experiment.context_id
slot = repo.list_trial_slots(conn, experiment_id)[0]

def outcome():
    return comparison_flow.comparison_view(conn, repo.get_experiment(conn, experiment_id))['outcome']

baseline = outcome()
assert baseline['status'] == 'COMPLETE' and all(e['eligible'] for e in baseline['eligibility'])
ctx = conn.execute('SELECT * FROM execution_contexts WHERE id=?', (context_id,)).fetchone()
workloads = json.loads(ctx['workloads_json'])
wrong_count = json.loads(ctx['workloads_json'])
wrong_count[0]['request_count'] += 1
wrong_specs = json.loads(ctx['workloads_json'])
specs = json.loads(base64.b64decode(wrong_specs[0]['request_specs_bytes_base64']))
specs[0]['id'] = 'wrong-frozen-request'
wrong_specs[0]['request_specs_bytes_base64'] = base64.b64encode(json.dumps(specs).encode()).decode()
mutations = [
    ('mission_hash', 'UPDATE execution_contexts SET mission_hash=? WHERE id=?', ('0'*64, context_id)),
    ('public_state_hash', 'UPDATE execution_contexts SET public_data_hash=? WHERE id=?', ('0'*64, context_id)),
    ('context_hash', 'UPDATE execution_contexts SET content_hash=? WHERE id=?', ('0'*64, context_id)),
    ('workload_count', 'UPDATE execution_contexts SET workloads_json=? WHERE id=?', (json.dumps(wrong_count), context_id)),
    ('workload_spec', 'UPDATE execution_contexts SET workloads_json=? WHERE id=?', (json.dumps(wrong_specs), context_id)),
    ('recorded_adapter', 'UPDATE runs SET adapter=? WHERE id=?', ('recorded', slot.run_id)),
    ('recorded_mode', 'UPDATE runs SET evidence_mode=? WHERE id=?', ('RECORDED_INSPECTION', slot.run_id)),
    ('wrong_run_purpose', 'UPDATE runs SET purpose=? WHERE id=?', ('OPERATION', slot.run_id)),
    ('run_binding', 'UPDATE runs SET experiment_id=? WHERE id=?', ('wrong-experiment', slot.run_id)),
    ('candidate_hash', 'UPDATE artifact_versions SET content_hash=? WHERE id=?', ('0'*64, slot.artifact_version_id)),
    ('missing_public_capture', 'DELETE FROM run_outputs WHERE run_id=? AND request_ordinal=1', (slot.run_id,)),
    ('missing_protected_capture', 'DELETE FROM run_outputs WHERE run_id=? AND request_ordinal=4', (slot.run_id,)),
    ('public_assessment', 'UPDATE task_assessments SET mandatory_pass=0 WHERE run_id=? AND request_ordinal=1 AND task_id=?', (slot.run_id, 'qualification')),
    ('protected_assessment', 'UPDATE task_assessments SET mandatory_pass=0 WHERE run_id=? AND request_ordinal=4 AND task_id=?', (slot.run_id, 'qualification')),
    ('failed_slot', 'UPDATE trial_slots SET state=? WHERE id=?', ('FAILED', slot.id)),
]
results = []
for name, sql, args in mutations:
    conn.execute('SAVEPOINT probe')
    try:
        changed = conn.execute(sql, args).rowcount
        assert changed > 0, (name, 'no-op mutation')
        result = outcome()
        denied = result['status'] != 'COMPLETE' and all(not e['eligible'] for e in result['eligibility'])
        results.append(dict(name=name, status=result['status'], eligibility_refused=denied,
                            drift_fields=result.get('drift_fields', []), altered_rows=changed))
    except sqlite3.IntegrityError as exc:
        denied = name == 'wrong_run_purpose' and 'UNIQUE constraint failed: runs.shift_id' in str(exc)
        results.append(dict(name=name, status='STORAGE_REFUSED', error=str(exc), eligibility_refused=denied))
    except Exception as exc:
        results.append(dict(name=name, status='UNEXPECTED_EXCEPTION', error=repr(exc), eligibility_refused=False))
    finally:
        conn.execute('ROLLBACK TO probe')
        conn.execute('RELEASE probe')
    assert outcome()['status'] == 'COMPLETE', name
conn.close()
(OUT / 'readback-probes.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
failed = [r for r in results if not r['eligibility_refused']]
print(json.dumps(dict(controls=len(results), caught=len(results)-len(failed), failures=failed)))
assert not failed, failed
