import hashlib
import json
from pathlib import Path
import zipfile

CHAT = Path(__file__).resolve().parents[1]
WORK = CHAT / 'work'
OUT = CHAT / 'outputs'
OUT.mkdir(exist_ok=True)
def read(name):
    return json.loads((WORK / name).read_bytes())
full = read('full-offline-result.json')
assert full['exit_code'] == full['failures'] == full['errors'] == 0
assert full['tests'] == 1282 and full['skipped'] == 1
summary = dict(verdict='PASS_WITHIN_APPROVED_OFFLINE_SCOPE', acceptance='PENDING_USER_DECISION',
               publication_authorized=False, full_offline=full,
               bindings=read('independent-bindings-audit.json'),
               database=read('independent-database-audit.json'),
               publication=read('independent-publication-audit.json'),
               faults=read('independent-fault-audit.json'),
               readback_probes=read('readback-probes.json'), preservation=read('review-preservation.json'),
               helper_rejections=[read('audit-first-rejection.json'), read('readback-first-rejection.json')],
               limitations=['packaging excluded', 'live conformance skipped', 'fresh Git checkout not run',
                            'no model-quality, CRM, learning, spending, or production-readiness proof',
                            'ignore/AGENTS ownership and historical whole-tree audit remain unresolved'])
summary_path = OUT / 's23-review-evidence.json'
with summary_path.open('x', encoding='utf-8') as stream:
    json.dump(summary, stream, indent=2)
    stream.write('\n')
names = ['review-plan.md', 'review-entry.json', 'review-preservation.json', 'isolated-entry.json',
         'independent-bindings-audit.json', 'independent-database-audit.json',
         'independent-publication-audit.json', 'independent-fault-audit.json',
         'readback-probes.json', 'audit-first-rejection.json', 'readback-first-rejection.json',
         'full-offline.log', 'full-offline.xml', 'full-offline-result.json',
         'audit_review.py', 'run_review_tests.py', 'prepare_isolated.py', 'probe_readback.py', 'finish_review.py']
files = [WORK / n for n in names] + sorted((WORK / 'faults-rerun').glob('*.log')) + sorted((WORK / 'faults-rerun').glob('*.xml')) + [WORK / 'faults-rerun/results.json']
with zipfile.ZipFile(OUT / 's23-review-evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        archive.write(path, path.relative_to(WORK).as_posix())
    archive.write(summary_path, summary_path.name)
with zipfile.ZipFile(OUT / 's23-review-evidence.zip') as archive:
    assert archive.testzip() is None
    for path in files:
        assert archive.read(path.relative_to(WORK).as_posix()) == path.read_bytes()
print(json.dumps(dict(verdict=summary['verdict'], evidence_files=len(files)+1,
                      evidence_zip_sha256=hashlib.sha256((OUT / 's23-review-evidence.zip').read_bytes()).hexdigest())))
